package mk.codeit.onlinesongslibrary.model.exceptions;

public class PlaylistException extends RuntimeException{
    public PlaylistException(String message) {
        super(message);
    }
}
