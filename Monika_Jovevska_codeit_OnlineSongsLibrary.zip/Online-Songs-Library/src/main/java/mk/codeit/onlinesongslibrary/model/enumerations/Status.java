package mk.codeit.onlinesongslibrary.model.enumerations;

public enum Status {
    PRIVATE,
    PUBLIC
}
