package mk.codeit.onlinesongslibrary.model.exceptions;

public class ArtistException extends RuntimeException{
    public ArtistException(String message) {
        super(message);
    }
}