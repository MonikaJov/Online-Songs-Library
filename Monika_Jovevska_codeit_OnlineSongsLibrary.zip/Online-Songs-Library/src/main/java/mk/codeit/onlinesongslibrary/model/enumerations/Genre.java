package mk.codeit.onlinesongslibrary.model.enumerations;

public enum Genre {
    POP,
    ROCK,
    METAL,
    COUNTRY,
    RAP,
    JAZZ,
    PUNK,
    HIPHOP,
    ALTERNATIVE,
    CLASSIC
}

