package mk.codeit.onlinesongslibrary;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineSongsLibraryApplication {
    public static void main(String[] args) throws Exception {
        SpringApplication.run(OnlineSongsLibraryApplication.class, args);
    }

}
