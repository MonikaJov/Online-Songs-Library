package mk.codeit.onlinesongslibrary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineSongsLibraryApplicationTests {

    @Test
    void contextLoads() {
    }

}
